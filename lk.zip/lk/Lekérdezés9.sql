SELECT lkSzem�lyek.[Besorol�si  fokozat (KT)]
FROM lkSzem�lyek;
