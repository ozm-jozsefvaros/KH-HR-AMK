SELECT lkSzem�lyek.*
FROM lkSzem�lyek;
