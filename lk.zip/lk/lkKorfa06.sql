SELECT lkKorfa04.Korcsoport AS Korcsoport, lkKorfa04.F�rfi AS F�rfi, lkKorfa04.N� AS N�
FROM lkKorfa04;
