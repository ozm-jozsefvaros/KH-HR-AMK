SELECT lkNevekTajOlt�shoz03.*
FROM lkNevekTajOlt�shoz03
UNION SELECT lkNevekTajOlt�shoz05.*
FROM lkNevekTajOlt�shoz05;
