SELECT DISTINCT lkTelephelyek.Sorsz�m, lkTelephelyek.C�m_Szem�lyek
FROM lkTelephelyek;
