SELECT DISTINCT lk_KiraHiba_01.TO, Count(lk_KiraHiba_01.Ad�azonos�t�) AS CountOfAd�azonos�t�
FROM lk_KiraHiba_01
GROUP BY lk_KiraHiba_01.TO;
