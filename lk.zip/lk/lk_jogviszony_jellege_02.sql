SELECT lk_Jogviszony_jellege_01.BFKH, lk_Jogviszony_jellege_01.[Dolgoz� teljes neve], lk_Jogviszony_jellege_01.F�oszt�ly, lk_Jogviszony_jellege_01.Oszt�ly, lk_Jogviszony_jellege_01.Kira, lk_Jogviszony_jellege_01.Nexon, lk_Jogviszony_jellege_01.NLink
FROM lk_Jogviszony_jellege_01
WHERE (((lk_Jogviszony_jellege_01.Nexon)<>[Kira]));
