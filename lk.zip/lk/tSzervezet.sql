SELECT tSzervezeti.*
FROM tSzervezeti;
