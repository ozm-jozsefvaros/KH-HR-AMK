PARAMETERS [__Sorsz�m] Value;
SELECT DISTINCTROW *
FROM ktSzervezetTelephely AS lkTelephelyek
WHERE ((([__Sorsz�m])=[azTelephely]));
