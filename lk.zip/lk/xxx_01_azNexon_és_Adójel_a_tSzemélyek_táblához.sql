ALTER TABLE tSzem�lyek
ADD COLUMN Ad�jel Double, azNexon Double;